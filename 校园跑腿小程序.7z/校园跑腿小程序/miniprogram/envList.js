const envList = [{"envId":"cloud1-3gnnfxpp2b1dda77","alias":"text"}]
const isMac = false
module.exports = {
    envList,
    isMac
}